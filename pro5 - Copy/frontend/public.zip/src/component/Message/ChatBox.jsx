import React, { useState } from 'react';

const ChatBox = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const handleSend = (event) => {
    event.preventDefault();
    if (input.trim()) {
      setMessages([...messages, input.trim()]);
      setInput('');
    }
  };

  return (
    <div className="w-80 h-96 border border-gray-300 rounded flex flex-col">
      <div className="flex-1 p-3 overflow-y-auto bg-gray-100">
        {messages.map((msg, index) => (
          <div key={index} className="mb-2 p-2 bg-gray-300 rounded max-w-[80%] text-black">
            {msg}
          </div>
        ))}
      </div>
      <form onSubmit={handleSend} className="flex border-t border-gray-300">
        <input
          type="text"
          placeholder="Type a message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 p-2 outline-none text-black"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-blue-500 text-white hover:bg-blue-600"
        >
          Send
        </button>
      </form>
    </div>
  );
};

export default ChatBox;
