# task-manager

### to run app
#### go to each individial folder and run yarn or yarn install
#### go back to root folder and run yarn start

