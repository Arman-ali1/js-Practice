import React from 'react';
import ChatBox from './component/Message/ChatBox';

function App() {
  return (
    <div className="App">
      <h1 className="text-2xl font-bold mb-4 ">Chat Application</h1>
      <ChatBox />
    </div>
  );
}

export default App;
